Scripts not in OpenROAD-flow-scripts, created for use within the OpenROAD flow in OpenFASOC.
